function confirmado() {
    let section_1 = document.getElementById("section_1");
    let section_2 = document.getElementById("section_2");

    section_1.style.opacity = 0;
    section_1.style.position = 'absolute';
    
    section_2.style.opacity= 1;
    section_2.style.top = 0;
}